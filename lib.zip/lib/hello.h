#ifndef _HELLO_T4_H
#define _HELLO_T4_H

void hello();

#endif

