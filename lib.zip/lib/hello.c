#include "stdio.h"
#include "hello.h"

void hello()
{
	printf("Hello World!\n");
}

